package com.example.annotationdel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnotationDelApplicationTests {

    @Test
    void contextLoads() {
    }

}
